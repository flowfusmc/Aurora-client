package com.aurora.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class AuroraClient implements ClientModInitializer {
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("aurora", "general"));
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aurora.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        HudElementRegistry.addLast(Identifier.of("aurora", "client_hud"), (context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || !AuroraFeatures.hud) return;
            int y = 8;
            context.fill(7, 6, 136, 25, 0xAA111722);
            context.fill(7, 6, 9, 25, 0xFF4C8DFF);
            context.drawText(client.textRenderer, Text.literal("AURORA CLIENT"), 14, 8, 0xFFFFFFFF, true);
            context.drawText(client.textRenderer, Text.literal("1.21.11 / FABRIC"), 14, 16, 0xFF9CA7BC, false);
            y += 24;
            if (AuroraFeatures.coordinates) {
                String coords = String.format("XYZ: %.1f / %.1f / %.1f", client.player.getX(), client.player.getY(), client.player.getZ());
                context.fill(7, y, 158, y + 13, 0xAA111722);
                context.drawText(client.textRenderer, Text.literal(coords), 12, y + 3, 0xFFE8EDF7, false);
                y += 16;
            }
            if (AuroraFeatures.fpsCounter) {
                context.fill(7, y, 90, y + 13, 0xAA111722);
                context.drawText(client.textRenderer, Text.literal("FPS: " + MinecraftClient.getCurrentFps()), 12, y + 3, 0xFF70A5FF, false);
                y += 16;
            }
            if (AuroraFeatures.keystrokes) {
                int x = 7;
                int top = y + 2;
                drawKey(context, client, "W", x + 22, top, client.options.forwardKey.isPressed());
                drawKey(context, client, "A", x, top + 20, client.options.leftKey.isPressed());
                drawKey(context, client, "S", x + 22, top + 20, client.options.backKey.isPressed());
                drawKey(context, client, "D", x + 44, top + 20, client.options.rightKey.isPressed());
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            AuroraFeatures.tick(client);
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen instanceof AuroraScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new AuroraScreen());
                }
            }
        });
    }

    private static void drawKey(net.minecraft.client.gui.DrawContext context, MinecraftClient client,
                                String label, int x, int y, boolean pressed) {
        int color = pressed ? 0xFF4C8DFF : 0xCC202431;
        context.fill(x, y, x + 19, y + 17, color);
        context.drawText(client.textRenderer, Text.literal(label), x + 6, y + 5, 0xFFFFFFFF, false);
    }
}
