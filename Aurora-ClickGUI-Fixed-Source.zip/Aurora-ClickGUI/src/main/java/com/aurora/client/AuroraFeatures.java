package com.aurora.client;

import net.minecraft.client.MinecraftClient;

/** Shared feature state and per-tick vanilla option effects. */
public final class AuroraFeatures {
    private AuroraFeatures() {}

    public static boolean hud = true;
    public static boolean coordinates = true;
    public static boolean fpsCounter = true;
    public static boolean keystrokes = false;
    public static boolean fullbright = false;
    public static boolean zoom = false;

    private static double originalGamma = Double.NaN;
    private static Integer originalFov = null;

    public static boolean isEnabled(String name) {
        return switch (name) {
            case "HUD" -> hud;
            case "Coordinates" -> coordinates;
            case "FPS Counter" -> fpsCounter;
            case "Keystrokes" -> keystrokes;
            case "Fullbright" -> fullbright;
            case "Zoom" -> zoom;
            default -> false;
        };
    }

    public static void toggle(String name) {
        switch (name) {
            case "HUD" -> hud = !hud;
            case "Coordinates" -> coordinates = !coordinates;
            case "FPS Counter" -> fpsCounter = !fpsCounter;
            case "Keystrokes" -> keystrokes = !keystrokes;
            case "Fullbright" -> fullbright = !fullbright;
            case "Zoom" -> zoom = !zoom;
        }
    }

    public static void tick(MinecraftClient client) {
        if (client == null || client.options == null) return;

        if (fullbright) {
            if (Double.isNaN(originalGamma)) originalGamma = client.options.getGamma().getValue();
            client.options.getGamma().setValue(16.0);
        } else if (!Double.isNaN(originalGamma)) {
            client.options.getGamma().setValue(originalGamma);
            originalGamma = Double.NaN;
        }

        if (zoom && client.player != null) {
            if (originalFov == null) originalFov = client.options.getFov().getValue();
            client.options.getFov().setValue(30);
        } else if (originalFov != null) {
            client.options.getFov().setValue(originalFov);
            originalFov = null;
        }
    }
}
