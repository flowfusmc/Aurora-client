package com.aurora.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/** Aurora's original dark, category-based click GUI. */
public final class AuroraScreen extends Screen {
    private static final int W = 520, H = 330;
    private static final int BG = 0xF20B0E14, PANEL = 0xFF121722, CARD = 0xFF191F2B;
    private static final int CARD_HOVER = 0xFF222B3B, BLUE = 0xFF5795FF, TEXT = 0xFFF1F5FC, MUTED = 0xFF8F9CB2;
    private static final int SIDEBAR = 132, ROW_H = 48;
    private final List<ModuleEntry> modules = new ArrayList<>();
    private final String[] categories = {"All Modules", "HUD", "Visuals"};
    private int category = 0, x, y, scroll = 0;
    private boolean dragging;
    private double dragX, dragY;

    public AuroraScreen() {
        super(Text.literal("Aurora Client"));
        modules.add(new ModuleEntry("HUD", "Client overlay and status", "HUD", true));
        modules.add(new ModuleEntry("Coordinates", "Player position display", "HUD", true));
        modules.add(new ModuleEntry("FPS Counter", "Current frames per second", "HUD", true));
        modules.add(new ModuleEntry("Keystrokes", "Live movement-key display", "HUD", false));
        modules.add(new ModuleEntry("Fullbright", "Increase world brightness", "Visuals", false));
        modules.add(new ModuleEntry("Zoom", "Toggle a closer field of view", "Visuals", false));
    }

    @Override protected void init() { x = (width - W) / 2; y = (height - H) / 2; }

    @Override public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0x9905080D);
        c.fill(x, y, x + W, y + H, BG);
        c.fill(x, y, x + W, y + 3, BLUE);
        c.fill(x, y + 3, x + SIDEBAR, y + H, PANEL);
        c.fill(x + SIDEBAR, y + 3, x + SIDEBAR + 1, y + H, 0xFF293244);

        c.drawText(textRenderer, Text.literal("AURORA"), x + 17, y + 17, TEXT, false);
        c.drawText(textRenderer, Text.literal("CLIENT  /  1.21.11"), x + 17, y + 34, MUTED, false);
        c.fill(x + 14, y + 57, x + SIDEBAR - 14, y + 58, 0xFF293244);
        for (int i = 0; i < categories.length; i++) {
            int cy = y + 70 + i * 31;
            boolean selected = i == category;
            if (selected) {
                c.fill(x + 9, cy - 5, x + SIDEBAR - 9, cy + 20, 0xFF202F48);
                c.fill(x + 9, cy - 5, x + 12, cy + 20, BLUE);
            }
            c.drawText(textRenderer, Text.literal(categories[i]), x + 20, cy + 3, selected ? TEXT : MUTED, false);
        }
        c.drawText(textRenderer, Text.literal("RIGHT SHIFT"), x + 16, y + H - 32, BLUE, false);
        c.drawText(textRenderer, Text.literal("TOGGLE MENU"), x + 16, y + H - 19, MUTED, false);

        int contentX = x + SIDEBAR + 18;
        c.drawText(textRenderer, Text.literal(categories[category]), contentX, y + 18, TEXT, false);
        c.drawText(textRenderer, Text.literal("Click a module to enable or disable it"), contentX, y + 35, MUTED, false);
        c.fill(contentX, y + 54, x + W - 18, y + 55, 0xFF293244);

        int rowY = y + 66;
        int visible = 0;
        for (ModuleEntry m : modules) {
            if (category != 0 && !m.category.equals(categories[category])) continue;
            if (visible++ < scroll) continue;
            if (rowY + ROW_H > y + H - 10) break;
            int right = x + W - 18;
            boolean hover = mouseX >= contentX && mouseX <= right && mouseY >= rowY && mouseY <= rowY + ROW_H - 5;
            c.fill(contentX, rowY, right, rowY + ROW_H - 5, hover ? CARD_HOVER : CARD);
            c.drawText(textRenderer, Text.literal(m.name), contentX + 11, rowY + 8, TEXT, false);
            c.drawText(textRenderer, Text.literal(m.description), contentX + 11, rowY + 24, MUTED, false);
            boolean enabled = AuroraFeatures.isEnabled(m.name);
            int sx = right - 39, sy = rowY + 14;
            c.fill(sx, sy, sx + 26, sy + 13, enabled ? BLUE : 0xFF3A4353);
            int knob = enabled ? sx + 15 : sx + 3;
            c.fill(knob, sy + 3, knob + 8, sy + 10, 0xFFFFFFFF);
            rowY += ROW_H;
        }
        if (visible == 0) c.drawText(textRenderer, Text.literal("No modules in this category"), contentX + 10, rowY + 8, MUTED, false);
        super.render(c, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        if (mx >= x && mx <= x + W && my >= y && my <= y + 48) {
            dragging = true; dragX = mx - x; dragY = my - y; return true;
        }
        if (mx >= x + 8 && mx <= x + SIDEBAR && my >= y + 65 && my < y + 70 + categories.length * 31) {
            int picked = (int)((my - (y + 65)) / 31);
            if (picked >= 0 && picked < categories.length) { category = picked; scroll = 0; return true; }
        }
        int contentX = x + SIDEBAR + 18, rowY = y + 66, visible = 0;
        for (ModuleEntry m : modules) {
            if (category != 0 && !m.category.equals(categories[category])) continue;
            if (visible++ < scroll) continue;
            if (rowY + ROW_H > y + H - 10) break;
            if (mx >= contentX && mx <= x + W - 18 && my >= rowY && my <= rowY + ROW_H - 5) {
                AuroraFeatures.toggle(m.name); return true;
            }
            rowY += ROW_H;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            x = clamp((int)(mx - dragX), 0, Math.max(0, width - W));
            y = clamp((int)(my - dragY), 0, Math.max(0, height - H)); return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0) dragging = false;
        return super.mouseReleased(mx, my, button);
    }
    @Override public boolean shouldPause() { return false; }
    private static int clamp(int n, int lo, int hi) { return Math.max(lo, Math.min(hi, n)); }

    private static final class ModuleEntry {
        final String name, description, category;
        ModuleEntry(String name, String description, String category, boolean initiallyEnabled) {
            this.name = name; this.description = description; this.category = category;
        }
    }
}
