@echo off
setlocal
cd /d "%~dp0"
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Install Gradle 8.14 or newer and ensure gradle is on PATH.
  exit /b 1
)
java -version
if errorlevel 1 exit /b 1
call gradle clean remapJar --no-daemon
if errorlevel 1 (
  echo Build failed. Copy the complete Gradle error output before retrying.
  exit /b 1
)
if not exist "build\libs\Aurora-Client-1.21.11.jar" (
  echo Expected remapped JAR was not produced.
  exit /b 1
)
echo Build succeeded: build\libs\Aurora-Client-1.21.11.jar
endlocal
