# Aurora Client 1.2.1 — Minecraft Java 1.21.11

Fabric client mod with a Right Shift click GUI.

## Build the correct distributable

**Install Java 21 and Gradle 8.14+** (or use the included GitHub Actions workflow).
From this directory, run:

```bat
gradle clean remapJar --no-daemon
```

The distributable is created at:

`build/libs/Aurora-Client-1.21.11.jar`

Install only that file. Do not install the `-dev.jar` output from the ordinary `jar` task.
Fabric Loom's `remapJar` task converts the development/Yarn-mapped classes into the runtime mappings expected by Fabric.

## Install safely

1. Close Minecraft.
2. Keep a backup of your existing mods folder.
3. Test the JAR in a separate Minecraft 1.21.11 Fabric profile first.
4. Put the JAR in that profile's `mods` folder and launch it.
5. Press Right Shift after the game reaches the title screen.

This source ZIP is not itself a compiled or runtime-tested JAR. The GitHub Actions workflow builds the remapped artifact; test that artifact in your exact Fabric/OneClient environment before relying on it.

## Current modules

HUD, Coordinates, FPS Counter, Keystrokes, Fullbright, and Zoom.
